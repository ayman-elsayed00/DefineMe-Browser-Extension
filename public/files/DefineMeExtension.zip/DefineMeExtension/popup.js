// popup.js

document.addEventListener('DOMContentLoaded', () => {
    const get_definition_btn = document.getElementById('get-definition-button');
    const close_btn = document.getElementById('close-button');
    const collegiateApiKey = 'b08acf08-368b-4122-8226-d381b7124c14';
    const medicalApiKey = 'b047c550-1fc8-4896-bbf1-38921e8d0fba';
  
    get_definition_btn.addEventListener('click', async (e) => {
      e.preventDefault();
  
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.id) {
          throw new Error('Unable to get active tab.');
        }
  
        console.log('Get Definition Button Clicked.');
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          function: getHighlightedWord,
        });
  
      } catch (error) {
        console.error('Error fetching definitions:', error);
        alert('An error occurred while fetching definitions. Please try again later.');
      }
    });
  
    function getHighlightedWord() {
        const selection = window.getSelection();
        const highlightedWord = selection.toString().trim().toLowerCase();
        const capitalizedWord = highlightedWord.charAt(0).toUpperCase() + highlightedWord.slice(1);
        console.log('Highlighted Word:', capitalizedWord);
      
        chrome.runtime.sendMessage({ highlightedWord: capitalizedWord });
      }
  
    close_btn.addEventListener('click', (e) => {
      e.preventDefault();
      console.log('Close Button Clicked. Closing popup.');
      window.close();
    });
  
    chrome.runtime.onMessage.addListener((message) => {
      if (message.highlightedWord) {
        console.log('Received highlighted word from content script:', message.highlightedWord);
        const word_span = document.getElementById('word');
        word_span.innerText = `Word: ${message.highlightedWord}`;
        fetchDefinitions(message.highlightedWord);
      }
    });
  
    async function fetchDefinitions(word) {
      const defination_box = document.querySelector('.def');
      const not_found = document.querySelector('.not_found');
  
      if (!defination_box || !not_found) {
        console.error('Error fetching definitions: DOM elements not found.');
        return;
      }
  
      defination_box.innerText = '';
      not_found.innerText = '';
  
      try {
        const responseCollegiate = await fetch(`https://www.dictionaryapi.com/api/v3/references/collegiate/json/${word}?key=${collegiateApiKey}`);
        const dataCollegiate = await responseCollegiate.json();
  
        const responseMedical = await fetch(`https://www.dictionaryapi.com/api/v3/references/medical/json/${word}?key=${medicalApiKey}`);
        const dataMedical = await responseMedical.json();
  
        const firstCollegiateDefinition = dataCollegiate[0]?.shortdef?.[0];
        const firstMedicalDefinition = dataMedical[0]?.shortdef?.[0];
  
        if (firstCollegiateDefinition) {
          defination_box.innerText += 'Collegiate Definition:\n' + firstCollegiateDefinition + '\n';
        } else {
          not_found.innerText = 'No result found in the Collegiate dictionary\n';
        }
  
        if (firstMedicalDefinition) {
          defination_box.innerText += '\nMedical Definition:\n' + firstMedicalDefinition;
        } else {
          not_found.innerText += 'No result found in the Medical dictionary';
        }
      } catch (error) {
        console.error('Error fetching definitions:', error);
        not_found.innerText = 'Error fetching definitions. Please try again later.';
      }
    }
    chrome.contextMenus.create({
        title: 'Define',
        contexts: ['selection'], // Show the menu item when text is selected
        onclick: (info) => {
          const highlightedWord = info.selectionText.trim().toLowerCase();
          console.log('Received highlighted word from context menu:', highlightedWord);
          fetchDefinitions(highlightedWord);
        },
      });
  });
  