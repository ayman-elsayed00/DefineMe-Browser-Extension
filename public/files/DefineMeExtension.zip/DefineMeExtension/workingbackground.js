// background.js

console.log('Background script loaded.');

chrome.contextMenus.create({
  id: "define-word",
  title: "Define '%s'",
  contexts: ["selection"],
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "define-word") {
    const highlightedWord = info.selectionText.trim().toLowerCase();
    if (highlightedWord) {
      console.log('Context menu item clicked. Highlighted Word:', highlightedWord);
      chrome.action.setPopup({ tabId: tab.id, popup: "popup.html" }, () => {
        chrome.tabs.sendMessage(tab.id, { word: highlightedWord });
      });
    }
  }
});
