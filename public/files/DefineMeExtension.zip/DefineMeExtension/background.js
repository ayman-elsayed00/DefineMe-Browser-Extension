console.log('Background script loaded.');

// Function to fetch and display definitions
async function fetchDefinitions(word) {
  try {
    // Fetch definitions from the Collegiate dictionary API
    const collegiateResponse = await fetch(`https://www.dictionaryapi.com/api/v3/references/collegiate/json/${word}?key=${collegiateApiKey}`);
    const collegiateData = await collegiateResponse.json();
    console.log('Collegiate data:', collegiateData);

    // Fetch definitions from the Medical dictionary API
    const medicalResponse = await fetch(`https://www.dictionaryapi.com/api/v3/references/medical/json/${word}?key=${medicalApiKey}`);
    const medicalData = await medicalResponse.json();
    console.log('Medical data:', medicalData);

    // Handle the data and send it to the popup for displaying definitions
    const definitionData = {
      word,
      collegiateDefinitions: [],
      medicalDefinitions: []
    };

    // Add Collegiate definitions
    if (collegiateData.length > 0 && Array.isArray(collegiateData[0].shortdef)) {
      definitionData.collegiateDefinitions = collegiateData[0].shortdef.slice(0, 1);
    }

    // Add Medical definitions
    if (medicalData.length > 0 && Array.isArray(medicalData[0].shortdef)) {
      definitionData.medicalDefinitions = medicalData[0].shortdef.slice(0, 1);
    }

    // Send the definition data to the popup
    chrome.runtime.sendMessage({ action: "displayDefinition", ...definitionData });
  } catch (error) {
    console.error('Error fetching definitions:', error);
    // Handle the error, show an error message, etc.
  }
}

// Create "Define" context menu item
chrome.contextMenus.removeAll(function() {
  chrome.contextMenus.create({
    id: "define-word",
    title: "Define '%s'",
    contexts: ["selection"],
  });
});

// Listener to handle context menu item clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "define-word") {
    const highlightedWord = info.selectionText.trim().toLowerCase();
    if (highlightedWord) {
      console.log('Context menu item clicked. Highlighted Word:', highlightedWord);

      // Send the highlighted word to the extension popup for displaying definitions
      chrome.action.setPopup({ tabId: tab.id, popup: "popup.html" }, () => {
        chrome.tabs.sendMessage(tab.id, { action: "getDefinition", word: highlightedWord });
      });
    }
  }
});

// Listener to handle messages sent from the content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "getDefinition") {
    const word = message.word;
    fetchDefinitions(word);
  }
});
