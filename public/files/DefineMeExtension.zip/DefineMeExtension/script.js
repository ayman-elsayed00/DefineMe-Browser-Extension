// script.js

const input = document.getElementById('input');
const search_btn = document.getElementById('search_btn');
const collegiateApiKey = 'b08acf08-368b-4122-8226-d381b7124c14';
const medicalApiKey = 'b047c550-1fc8-4896-bbf1-38921e8d0fba';

search_btn.addEventListener('click', e => {
  e.preventDefault();

  const word = input.value.trim().toLowerCase();
  if (word === '') {
    alert('Please type a word');
    return;
  }

  fetchDefinitions(word);
});

async function fetchDefinitions(word) {
  try {
    // Fetch definitions from the Collegiate dictionary API
    const collegiateResponse = await fetch(`https://www.dictionaryapi.com/api/v3/references/collegiate/json/${word}?key=${collegiateApiKey}`);
    const collegiateData = await collegiateResponse.json();
    console.log('Collegiate data:', collegiateData);

    // Fetch definitions from the Medical dictionary API
    const medicalResponse = await fetch(`https://www.dictionaryapi.com/api/v3/references/medical/json/${word}?key=${medicalApiKey}`);
    const medicalData = await medicalResponse.json();
    console.log('Medical data:', medicalData);

    // Handle the data and display the definitions on the page
    const defination_box = document.querySelector('.def');
    const audio_box = document.querySelector('.audio');
    const not_found = document.querySelector('.not_found');
    defination_box.innerText = '';
    audio_box.innerHTML = '';
    not_found.innerText = '';

    // Display first definition from Collegiate dictionary
    if (collegiateData.length > 0 && Array.isArray(collegiateData[0].shortdef)) {
      const firstCollegiateDefinition = collegiateData[0].shortdef[0];
      if (firstCollegiateDefinition) {
        defination_box.innerText += 'Collegiate Definition:\n' + firstCollegiateDefinition + '\n';
      } else {
        not_found.innerText = 'No result found in the Collegiate dictionary';
      }
    } else {
      not_found.innerText = 'No result found in the Collegiate dictionary';
    }

    // Display first definition from Medical dictionary
    if (medicalData.length > 0 && Array.isArray(medicalData[0].shortdef)) {
      const firstMedicalDefinition = medicalData[0].shortdef[0];
      if (firstMedicalDefinition) {
        defination_box.innerText += '\nMedical Definition:\n' + firstMedicalDefinition;
      } else {
        not_found.innerText = 'No result found in the Medical dictionary';
      }
    } else {
      not_found.innerText = 'No result found in the Medical dictionary';
    }

  } catch (error) {
    console.error('Error fetching definitions:', error);
    // Handle the error, show an error message, etc.
  }
}

// The rest of the soundRender function and event listeners remain unchanged.
