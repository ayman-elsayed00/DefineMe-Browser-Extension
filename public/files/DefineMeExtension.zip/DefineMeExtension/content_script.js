// content_script.js

// Function to create the "Define" button on the webpage
function createDefineButton() {
    const defineButton = document.createElement('button');
    defineButton.textContent = 'Define';
    defineButton.classList.add('define-button');
  
    // Add event listener to the "Define" button
    defineButton.addEventListener('click', () => {
      const highlightedWord = window.getSelection().toString().trim().toLowerCase();
      if (highlightedWord) {
        console.log('Define Button Clicked. Highlighted Word:', highlightedWord);
        // Send the highlighted word to the background script
        chrome.runtime.sendMessage({ action: "sendHighlightedWord", word: highlightedWord });
      }
    });
  
    // Append the "Define" button to the body of the webpage
    document.body.appendChild(defineButton);
  }
  
  // Add event listener to detect right-clicks on the webpage
  document.addEventListener('mouseup', (event) => {
    const highlightedWord = window.getSelection().toString().trim().toLowerCase();
    if (highlightedWord) {
      console.log('Highlighted Word:', highlightedWord);
      // Send the highlighted word to the background script
      chrome.runtime.sendMessage({ action: "sendHighlightedWord", word: highlightedWord });
    }
  });
  
  // Function to send highlighted word to the background script
  function sendHighlightedWord(word) {
    chrome.runtime.sendMessage({ action: "getDefinition", word: word });
  }
  
  // Add event listener to receive messages from background script
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "displayDefinition") {
      const { word, collegiateDefinitions, medicalDefinitions } = message;
  
      // Display the word and definitions on the webpage
      const definitionContainer = document.createElement('div');
      definitionContainer.classList.add('definition-container');
  
      const wordElement = document.createElement('p');
      wordElement.textContent = `Word: ${word}`;
      definitionContainer.appendChild(wordElement);
  
      const collegiateElement = document.createElement('p');
      collegiateElement.textContent = `Collegiate Definition: ${collegiateDefinitions.join(', ')}`;
      definitionContainer.appendChild(collegiateElement);
  
      const medicalElement = document.createElement('p');
      medicalElement.textContent = `Medical Definition: ${medicalDefinitions.join(', ')}`;
      definitionContainer.appendChild(medicalElement);
  
      // Remove any existing definition containers before adding the new one
      const existingDefinitionContainer = document.querySelector('.definition-container');
      if (existingDefinitionContainer) {
        existingDefinitionContainer.remove();
      }
  
      // Append the new definition container to the body of the webpage
      document.body.appendChild(definitionContainer);
    }
  });
  
  // Create the "Define" button on the webpage
  createDefineButton();
  